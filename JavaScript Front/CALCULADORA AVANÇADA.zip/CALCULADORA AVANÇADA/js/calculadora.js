    let divRes = document.querySelector('div#resultado')
    let operacao = tipoCalculo.toUpperCase();
    let valor = document.getElementById('valor').value

    function operacao (op){
        valor1 = Number(valor)
        document.getElementById('valor').value = ''
    }

    function calcular (tipoCalculo){
            switch (tipoCalculo) {
                case somar:
                    '+'
                    break;
            
                default:
                    break;
            }
    }

    function limpar(){
        valor.value= ''
        document.getElementById('resultado').innerText = ''
    }

    const somar = document.getElementById('somar')
    somar.addEventListener('click', () => {
        calcular()
    })

    const subtrair = document.getElementById('subtrair')
    subtrair.addEventListener('click', () => {
        calcular()
    })

    const multiplicar = document.getElementById('multiplicar')
    multiplicar.addEventListener('click', () => {
        calcular()
    })

    const dividir = document.getElementById('dividir')
    dividir.addEventListener('click', () => {
        calcular()
    })

    const clear = document.getElementById('limpar')
    clear.addEventListener('click', () => {
        limpar()
    })

    const igual = document.getElementById('igual')
    igual.addEventListener('click', () => {
        operacao()
    }) 