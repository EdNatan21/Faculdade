let somar = '+'
let n1 = '2'
let n2 = 5
let resultado = eval(`${n1} ${somar} ${n2}`)
console.log(`${resultado}`)